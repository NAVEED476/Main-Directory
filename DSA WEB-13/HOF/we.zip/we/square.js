var arr=[1,2,3,4,5]
var sum1=0
var sum=function(num){
    console.log(num**2)
}

arr.forEach(sum)

