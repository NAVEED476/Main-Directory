var arr=[1,2]

var d=function(num){
    console.log( 2*num)
}
arr.forEach(d)
