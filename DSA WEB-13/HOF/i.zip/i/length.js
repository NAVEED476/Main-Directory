var strin=["naveed","naveed","naveed"]

var l=function(str){
    return str.length
}

var res=strin.map(l)
console.log(res)