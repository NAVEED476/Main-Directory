var str=["masai","naveed","dssd"]

var f=function(num){
    return num[0]
}
var res=str.map(f)
console.log(res)