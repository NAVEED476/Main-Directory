var arr=["assignment", "problem", "media", "upload"]


var f=function(num){
    
    if  (num[0]=="a" || num[num.length-1]=="a"){
        return arr.join(" ")
    }
    
}
var res=arr.filter(f)
console.log(res)